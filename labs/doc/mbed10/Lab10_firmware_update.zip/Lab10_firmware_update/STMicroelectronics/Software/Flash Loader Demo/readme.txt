/******************** (C) COPYRIGHT 2015 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : MCD Application Team
* Version            : V2.8.0
* Date               : 01-September-2015
* Description        : readme file for Flash Loader Demonstrator
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
********************************************************************************
* FOR MORE INFORMATION PLEASE CAREFULLY READ THE LICENSE AGREEMENT FILE
* "MCD-ST Liberty SW License Agreement V2.pdf"
*******************************************************************************/

Last version V2.8.0 -  01-September-2015

Supported Microsoft OS:

  Windows 98SE, 2000, XP, Vista, 7, 8, 8.1, 10

How to use :

  1- Uninstall previous versions:
      
     use "Start-> Settings-> Control Panel-> Add or Remove Programs"
     to remove the old versions V2.x.y

  2- Run the setup


******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE******
